# GTA 6 AI Clipper — iPhone web app (starter MVP)

## यह वर्जन क्या करता है
- iPhone Safari में खुलने वाला responsive web app.
- वीडियो upload या HTTPS direct video-file URL.
- FFmpeg से 7 अलग MP4 clips बनाता है.
- हर clip को 9:16, 1080×1920 में center-crop करता है.
- प्रत्येक clip के लिए अलग download link.

## अभी क्या नहीं करता
यह पहला MVP वायरल moments को AI से पहचानता नहीं है। यह पूरे वीडियो में सात बराबर दूरी वाले हिस्से चुनता है। Auto Hindi subtitles भी अभी शामिल नहीं हैं। यह जानबूझकर स्पष्ट रखा गया है ताकि ऐप अपनी क्षमता के बारे में गलत दावा न करे.

## YouTube लिंक
YouTube watch/share URL को सीधे डाउनलोड नहीं करता। अपने चैनल/वीडियो के लिए YouTube Studio के आधिकारिक Download विकल्प का उपयोग करें, या ऐसा direct video-file URL दें जिसे डाउनलोड करने का आपको अधिकार हो और जिसकी hosting terms इसकी अनुमति देती हों। फिर MP4/MOV को ऐप में upload करें.

## लोकल चलाने के लिए
आवश्यक: Python 3.11+, FFmpeg + ffprobe.

```bash
pip install -r requirements.txt
python app.py
```
फिर उसी नेटवर्क पर iPhone से `http://COMPUTER-LAN-IP:8080` खोलें.

## इंटरनेट पर मुफ्त डिप्लॉय
1. इस ZIP को unzip करके GitHub repository में upload करें.
2. Render पर account बनाकर **New + → Blueprint** चुनें और repository connect करें.
3. Render `render.yaml` पढ़कर Docker service बनाएगा.
4. Deploy के बाद Render URL को iPhone Safari में खोलें.
5. Safari Share → Add to Home Screen.

ध्यान दें: Render का free tier sleep/ephemeral storage/compute limits रख सकता है। बड़ी वीडियो फाइलें या लंबे jobs free tier पर असफल हो सकते हैं। उत्पादन उपयोग के लिए persistent storage और background worker चाहिए.

## सुरक्षा / सीमाएँ
- Upload limit 2 GB है; hosting provider की अपनी सीमा इससे कम हो सकती है.
- यह demo authentication और automatic cleanup नहीं देता; सार्वजनिक रूप से deploy करने से पहले access control, file cleanup, rate limits और persistent storage जोड़ें.
- वीडियो के अधिकार और प्लेटफॉर्म की शर्तों का पालन करें.
