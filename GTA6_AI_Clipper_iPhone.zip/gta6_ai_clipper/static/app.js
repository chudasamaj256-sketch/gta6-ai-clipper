const $=id=>document.getElementById(id);
let timer=null;
$("go").addEventListener("click", async()=>{
 const file=$("video").files[0], url=$("url").value.trim();
 if(!file&&!url){$("status").textContent="पहले वीडियो चुनें या सीधा वीडियो फ़ाइल URL दें।";return}
 if(!$("rights").checked){$("status").textContent="आगे बढ़ने के लिए वीडियो इस्तेमाल करने की अनुमति की पुष्टि करें।";return}
 const fd=new FormData(); if(file)fd.append("video",file); else fd.append("video_url",url);
 $("go").disabled=true;$("status").textContent="वीडियो अपलोड हो रहा है…";$("results").innerHTML="";
 try{
  const r=await fetch("/api/create",{method:"POST",body:fd});const data=await r.json();
  if(!r.ok)throw new Error(data.error||"काम शुरू नहीं हुआ");
  $("status").textContent="वीडियो प्रोसेस हो रहा है… पेज खुला रखें।";
  poll(data.job_id);
 }catch(e){$("status").textContent=e.message;$("go").disabled=false}
});
async function poll(id){
 try{
  const r=await fetch("/api/status/"+id),d=await r.json();
  if(d.status==="done"){
   $("status").textContent="तैयार! नीचे से सातों MP4 डाउनलोड करें।";
   $("results").innerHTML=d.clips.map(c=>`<div class="clip"><span>${c.name}<br><small>${c.duration}s • ${c.start}s से</small></span><a href="${c.url}">डाउनलोड ↓</a></div>`).join("");
   $("go").disabled=false;return;
  }
  if(d.status==="error")throw new Error(d.error||"वीडियो प्रोसेस नहीं हो सका");
  $("status").textContent="वीडियो प्रोसेस हो रहा है… तैयार क्लिप: "+d.clips.length+"/7";
  timer=setTimeout(()=>poll(id),2500);
 }catch(e){$("status").textContent=e.message;$("go").disabled=false}
}
