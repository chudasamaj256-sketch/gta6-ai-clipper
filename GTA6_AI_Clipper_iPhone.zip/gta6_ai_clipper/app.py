import os, uuid, subprocess, json, shutil, threading
from pathlib import Path
from urllib.parse import urlparse
from flask import Flask, request, jsonify, render_template, send_from_directory, abort
import requests

BASE = Path(__file__).parent.resolve()
UPLOADS = BASE / "uploads"
OUTPUTS = BASE / "outputs"
UPLOADS.mkdir(exist_ok=True); OUTPUTS.mkdir(exist_ok=True)
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024 * 1024
JOBS = {}
ALLOWED = {".mp4", ".mov", ".m4v", ".webm", ".mkv"}

def run(cmd):
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode:
        raise RuntimeError((p.stderr or p.stdout)[-2500:])
    return p.stdout

def probe(path):
    raw = run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "json", str(path)])
    return float(json.loads(raw)["format"]["duration"])

def make_clips(job_id, source):
    try:
        JOBS[job_id]["status"] = "processing"
        duration = probe(source)
        if duration < 12:
            raise ValueError("वीडियो कम से कम 12 सेकंड का होना चाहिए।")
        clip_len = min(45, max(15, duration / 7 * 0.72))
        # Spread seven non-overlapping windows across the source.
        max_start = max(0, duration - clip_len)
        starts = [max_start * i / 6 for i in range(7)]
        outdir = OUTPUTS / job_id
        outdir.mkdir(exist_ok=True)
        clips = []
        for i, start in enumerate(starts, 1):
            out = outdir / f"GTA6_Short_{i}.mp4"
            vf = "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920"
            run(["ffmpeg", "-y", "-ss", f"{start:.2f}", "-i", str(source),
                 "-t", f"{clip_len:.2f}", "-vf", vf, "-c:v", "libx264",
                 "-preset", "veryfast", "-crf", "23", "-c:a", "aac",
                 "-b:a", "128k", "-movflags", "+faststart", str(out)])
            clips.append({"name": out.name, "url": f"/download/{job_id}/{out.name}",
                          "start": round(start, 1), "duration": round(clip_len, 1)})
            JOBS[job_id]["clips"] = clips[:]
        JOBS[job_id]["status"] = "done"
    except Exception as e:
        JOBS[job_id]["status"] = "error"
        JOBS[job_id]["error"] = str(e)

@app.get("/")
def home():
    return render_template("index.html")

@app.post("/api/create")
def create():
    job_id = uuid.uuid4().hex[:12]
    f = request.files.get("video")
    direct_url = (request.form.get("video_url") or "").strip()
    if f and f.filename:
        ext = Path(f.filename).suffix.lower()
        if ext not in ALLOWED:
            return jsonify(error="कृपया MP4, MOV, M4V, WEBM या MKV वीडियो चुनें।"), 400
        source = UPLOADS / f"{job_id}{ext}"
        f.save(source)
    elif direct_url:
        # Only direct media-file URLs; YouTube watch pages are intentionally not fetched.
        parsed = urlparse(direct_url)
        if parsed.scheme != "https" or not parsed.hostname:
            return jsonify(error="सुरक्षित HTTPS वीडियो फ़ाइल लिंक दें।"), 400
        if "youtube.com" in parsed.hostname or "youtu.be" in parsed.hostname:
            return jsonify(error="YouTube पेज लिंक सीधे डाउनलोड नहीं किया जाता। अपने अधिकार वाले वीडियो को YouTube Studio से डाउनलोड करके यहाँ अपलोड करें।"), 400
        try:
            r = requests.get(direct_url, stream=True, timeout=25, headers={"User-Agent":"GTA6Clipper/1.0"})
            r.raise_for_status()
            content_type = r.headers.get("content-type", "")
            if not (content_type.startswith("video/") or urlparse(r.url).path.lower().endswith(tuple(ALLOWED))):
                return jsonify(error="यह सीधा वीडियो फ़ाइल लिंक नहीं लगता। वीडियो फ़ाइल अपलोड करें।"), 400
            source = UPLOADS / f"{job_id}.mp4"
            total = 0
            with open(source, "wb") as w:
                for chunk in r.iter_content(1024*1024):
                    if chunk:
                        total += len(chunk)
                        if total > 2*1024*1024*1024:
                            raise ValueError("वीडियो 2 GB से बड़ा है।")
                        w.write(chunk)
        except Exception as e:
            return jsonify(error=f"लिंक से वीडियो नहीं मिला: {e}"), 400
    else:
        return jsonify(error="वीडियो अपलोड करें या सीधा वीडियो फ़ाइल लिंक पेस्ट करें।"), 400

    JOBS[job_id] = {"status":"queued", "clips":[], "error":None}
    threading.Thread(target=make_clips, args=(job_id, source), daemon=True).start()
    return jsonify(job_id=job_id)

@app.get("/api/status/<job_id>")
def status(job_id):
    if job_id not in JOBS: abort(404)
    return jsonify(JOBS[job_id])

@app.get("/download/<job_id>/<filename>")
def download(job_id, filename):
    folder = OUTPUTS / job_id
    if not folder.exists() or Path(filename).name != filename: abort(404)
    return send_from_directory(folder, filename, as_attachment=True)

@app.get("/health")
def health():
    return "ok"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)), debug=False)
